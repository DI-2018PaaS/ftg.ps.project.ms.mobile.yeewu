import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-client-statistiques',
  templateUrl: 'client-statistiques.html'
})
export class ClientStatistiquesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
