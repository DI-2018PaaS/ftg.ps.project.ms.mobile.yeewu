import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-devis-offre',
  templateUrl: 'devis-offre.html'
})
export class DevisOffrePage {

  constructor(public navCtrl: NavController) {
  }
  
}
