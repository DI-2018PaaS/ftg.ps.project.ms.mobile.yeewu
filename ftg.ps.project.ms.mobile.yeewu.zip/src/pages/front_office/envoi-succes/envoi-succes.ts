import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-envoi-succes',
  templateUrl: 'envoi-succes.html'
})
export class EnvoiSuccesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
