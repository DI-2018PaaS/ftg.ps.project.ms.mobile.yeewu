import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-domaine',
  templateUrl: 'domaine.html'
})
export class DomainePage {

  constructor(public navCtrl: NavController) {
  }
  
}
