import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-echec-envoi',
  templateUrl: 'echec-envoi.html'
})
export class EchecEnvoiPage {

  constructor(public navCtrl: NavController) {
  }
  
}
