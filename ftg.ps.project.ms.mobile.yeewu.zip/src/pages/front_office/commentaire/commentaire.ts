import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-commentaire',
  templateUrl: 'commentaire.html'
})
export class CommentairePage {

  constructor(public navCtrl: NavController) {
  }
  
}
