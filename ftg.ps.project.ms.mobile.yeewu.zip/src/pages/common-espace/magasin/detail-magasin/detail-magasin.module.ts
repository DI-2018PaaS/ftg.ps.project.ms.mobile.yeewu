import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailMagasinPage } from './detail-magasin';

@NgModule({
  declarations: [
    DetailMagasinPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailMagasinPage),
  ],
})
export class DetailMagasinPageModule {}
