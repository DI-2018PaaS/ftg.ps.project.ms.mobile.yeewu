import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditMagasinPage } from './edit-magasin';

@NgModule({
  declarations: [
    EditMagasinPage,
  ],
  imports: [
    IonicPageModule.forChild(EditMagasinPage),
  ],
})
export class EditMagasinPageModule {}
