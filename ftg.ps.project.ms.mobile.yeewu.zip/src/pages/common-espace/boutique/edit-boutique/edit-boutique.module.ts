import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditBoutiquePage } from './edit-boutique';

@NgModule({
  declarations: [
    EditBoutiquePage,
  ],
  imports: [
    IonicPageModule.forChild(EditBoutiquePage),
  ],
})
export class EditBoutiquePageModule {}
