import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-commande',
  templateUrl: 'detail-commande.html'
})
export class DetailCommandePage {

  constructor(public navCtrl: NavController) {
  }
  
}
