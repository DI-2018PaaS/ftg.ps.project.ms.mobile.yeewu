import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-enchere',
  templateUrl: 'detail-enchere.html'
})
export class DetailEncherePage {

  constructor(public navCtrl: NavController) {
  }
  
}
