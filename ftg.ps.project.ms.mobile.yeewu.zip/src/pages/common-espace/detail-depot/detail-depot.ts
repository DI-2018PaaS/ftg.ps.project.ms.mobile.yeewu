import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-depot',
  templateUrl: 'detail-depot.html'
})
export class DetailDepotPage {

  constructor(public navCtrl: NavController) {
  }
  
}
