import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-demande',
  templateUrl: 'detail-demande.html'
})
export class DetailDemandePage {

  constructor(public navCtrl: NavController) {
  }
  
}
