import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-user',
  templateUrl: 'detail-user.html'
})
export class DetailUserPage {

  constructor(public navCtrl: NavController) {
  }
  
}
