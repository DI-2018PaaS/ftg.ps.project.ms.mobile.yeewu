import { DetailsEncherePage } from './details-enchere';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

@NgModule({
  declarations: [
    DetailsEncherePage,
  ],
  imports: [
    IonicPageModule.forChild(DetailsEncherePage),
  ],
})
export class DetailsEncherePageModule {}
