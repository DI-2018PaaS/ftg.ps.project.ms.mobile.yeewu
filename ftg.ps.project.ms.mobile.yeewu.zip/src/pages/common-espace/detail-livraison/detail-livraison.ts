import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-livraison',
  templateUrl: 'detail-livraison.html'
})
export class DetailLivraisonPage {

  constructor(public navCtrl: NavController) {
  }
  
}
