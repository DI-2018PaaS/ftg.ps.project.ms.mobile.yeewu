import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-notation',
  templateUrl: 'detail-notation.html'
})
export class DetailNotationPage {

  constructor(public navCtrl: NavController) {
  }
  
}
