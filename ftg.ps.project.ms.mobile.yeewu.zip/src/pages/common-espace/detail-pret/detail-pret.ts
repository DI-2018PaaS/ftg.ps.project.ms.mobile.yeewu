import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-pret',
  templateUrl: 'detail-pret.html'
})
export class DetailPretPage {

  constructor(public navCtrl: NavController) {
  }
  
}
