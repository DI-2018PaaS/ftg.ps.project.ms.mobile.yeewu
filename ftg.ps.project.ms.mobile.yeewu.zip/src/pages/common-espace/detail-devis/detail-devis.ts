import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-detail-devis',
  templateUrl: 'detail-devis.html'
})
export class DetailDevisPage {

  constructor(public navCtrl: NavController) {
  }
  
}
