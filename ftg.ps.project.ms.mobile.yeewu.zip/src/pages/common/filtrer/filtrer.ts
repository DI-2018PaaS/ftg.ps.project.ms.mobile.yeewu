import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-filtrer',
  templateUrl: 'filtrer.html'
})
export class FiltrerPage {

  constructor(public navCtrl: NavController) {
  }
  
}
