import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-trier',
  templateUrl: 'trier.html'
})
export class TrierPage {

  constructor(public navCtrl: NavController) {
  }
  
}
