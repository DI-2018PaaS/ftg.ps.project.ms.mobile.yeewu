import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-banque-statistiques',
  templateUrl: 'banque-statistiques.html'
})
export class BanqueStatistiquesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
