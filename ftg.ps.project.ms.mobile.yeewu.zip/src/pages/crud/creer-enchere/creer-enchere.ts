import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-enchere',
  templateUrl: 'creer-enchere.html'
})
export class CreerEncherePage {

  constructor(public navCtrl: NavController) {
  }
  
}
