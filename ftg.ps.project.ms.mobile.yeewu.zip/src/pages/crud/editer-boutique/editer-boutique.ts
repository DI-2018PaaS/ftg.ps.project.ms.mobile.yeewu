import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-boutique',
  templateUrl: 'editer-boutique.html'
})
export class EditerBoutiquePage {

  constructor(public navCtrl: NavController) {
  }
  
}
