import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-role',
  templateUrl: 'creer-role.html'
})
export class CreerRolePage {

  constructor(public navCtrl: NavController) {
  }
  
}
