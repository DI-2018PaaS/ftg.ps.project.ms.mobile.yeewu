import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-view-compte',
  templateUrl: 'view-compte.html'
})
export class ViewComptePage {

  constructor(public navCtrl: NavController) {
  }
  
}
