import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-enchere',
  templateUrl: 'editer-enchere.html'
})
export class EditerEncherePage {

  constructor(public navCtrl: NavController) {
  }
  
}
