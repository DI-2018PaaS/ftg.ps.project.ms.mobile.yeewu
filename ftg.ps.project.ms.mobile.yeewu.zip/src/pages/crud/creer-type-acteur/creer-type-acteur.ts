import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-type-acteur',
  templateUrl: 'creer-type-acteur.html'
})
export class CreerTypeActeurPage {

  constructor(public navCtrl: NavController) {
  }
  
}
