import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-activit',
  templateUrl: 'creer-activit.html'
})
export class CreerActivitPage {

  constructor(public navCtrl: NavController) {
  }
  
}
