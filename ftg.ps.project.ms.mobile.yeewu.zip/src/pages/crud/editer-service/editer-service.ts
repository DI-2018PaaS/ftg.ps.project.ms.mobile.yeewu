import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-service',
  templateUrl: 'editer-service.html'
})
export class EditerServicePage {

  constructor(public navCtrl: NavController) {
  }
  
}
