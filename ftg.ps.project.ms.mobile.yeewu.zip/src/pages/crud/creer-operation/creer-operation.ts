import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-operation',
  templateUrl: 'creer-operation.html'
})
export class CreerOperationPage {

  constructor(public navCtrl: NavController) {
  }
  
}
