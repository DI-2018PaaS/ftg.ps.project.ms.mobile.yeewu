import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-magasin',
  templateUrl: 'creer-magasin.html'
})
export class CreerMagasinPage {

  constructor(public navCtrl: NavController) {
  }
  
}
