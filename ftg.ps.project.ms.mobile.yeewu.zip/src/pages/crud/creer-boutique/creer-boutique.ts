import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-boutique',
  templateUrl: 'creer-boutique.html'
})
export class CreerBoutiquePage {

  constructor(public navCtrl: NavController) {
  }
  
}
