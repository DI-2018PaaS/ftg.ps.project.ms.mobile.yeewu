import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-offre',
  templateUrl: 'editer-offre.html'
})
export class EditerOffrePage {

  constructor(public navCtrl: NavController) {
  }
  
}
