import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-compte',
  templateUrl: 'creer-compte.html'
})
export class CreerComptePage {

  constructor(public navCtrl: NavController) {
  }
  
}
