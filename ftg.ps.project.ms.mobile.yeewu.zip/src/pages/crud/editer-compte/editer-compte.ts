import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-compte',
  templateUrl: 'editer-compte.html'
})
export class EditerComptePage {

  constructor(public navCtrl: NavController) {
  }
  
}
