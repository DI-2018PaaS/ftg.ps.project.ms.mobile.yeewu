import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-service',
  templateUrl: 'creer-service.html'
})
export class CreerServicePage {

  constructor(public navCtrl: NavController) {
  }
  
}
