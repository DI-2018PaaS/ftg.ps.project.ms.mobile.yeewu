import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-produit',
  templateUrl: 'editer-produit.html'
})
export class EditerProduitPage {

  constructor(public navCtrl: NavController) {
  }
  
}
