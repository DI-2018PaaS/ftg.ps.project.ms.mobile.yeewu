import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-categorie',
  templateUrl: 'creer-categorie.html'
})
export class CreerCategoriePage {

  constructor(public navCtrl: NavController) {
  }
  
}
