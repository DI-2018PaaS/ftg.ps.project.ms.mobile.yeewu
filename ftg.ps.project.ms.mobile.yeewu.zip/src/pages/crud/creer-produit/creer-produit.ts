import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-produit',
  templateUrl: 'creer-produit.html'
})
export class CreerProduitPage {

  constructor(public navCtrl: NavController) {
  }
  
}
