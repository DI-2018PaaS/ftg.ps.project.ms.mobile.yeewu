import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-administrateur-statistiques',
  templateUrl: 'administrateur-statistiques.html'
})
export class AdministrateurStatistiquesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
