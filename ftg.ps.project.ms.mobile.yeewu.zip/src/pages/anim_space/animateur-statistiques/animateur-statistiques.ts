import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-animateur-statistiques',
  templateUrl: 'animateur-statistiques.html'
})
export class AnimateurStatistiquesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
