import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-fournisseur-statistiques',
  templateUrl: 'fournisseur-statistiques.html'
})
export class FournisseurStatistiquesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
