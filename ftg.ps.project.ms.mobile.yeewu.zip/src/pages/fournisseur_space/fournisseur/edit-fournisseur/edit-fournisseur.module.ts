import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditFournisseurPage } from './edit-fournisseur';

@NgModule({
  declarations: [
    EditFournisseurPage,
  ],
  imports: [
    IonicPageModule.forChild(EditFournisseurPage),
  ],
})
export class EditFournisseurPageModule {}
