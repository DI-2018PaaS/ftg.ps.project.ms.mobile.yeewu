import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailFournisseurPage } from './detail-fournisseur';

@NgModule({
  declarations: [
    DetailFournisseurPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailFournisseurPage),
  ],
})
export class DetailFournisseurPageModule {}
