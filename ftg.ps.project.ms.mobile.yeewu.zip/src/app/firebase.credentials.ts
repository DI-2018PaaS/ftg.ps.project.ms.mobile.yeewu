/*export const FIREBASE_CREDENTIALS={
    
    apiKey: "AIzaSyDjMPdloIvb0mmFgFWPnB5AoOYx9fluXL0",
    authDomain: "pocyewuna.firebaseapp.com",
    databaseURL: "https://pocyewuna.firebaseio.com",
    projectId: "pocyewuna",
    storageBucket: "pocyewuna.appspot.com",
    messagingSenderId: "681775832461"
  
}*/
export const FIREBASE_CREDENTIALS={
    
    apiKey: "AIzaSyDVtRuF2pdVJKRqFRr8qXLS8wqRPw0srzA",
    authDomain: "ftgpaasyeewu.firebaseapp.com",
    databaseURL: "https://ftgpaasyeewu.firebaseio.com",
    projectId: "ftgpaasyeewu",
    storageBucket: "ftgpaasyeewu.appspot.com",
    messagingSenderId: "542690483880"
  
}