export class Utilisateur {
    key?: string;
    username: string;
    utilUniqueid: number;
    lastName: string;
    firstName: string;
    mail: string;
    phoneNumber: string;
    password: string;
    creationDateUser: string;
    lastConnectionDate: string;
    userActeurID: number;
}