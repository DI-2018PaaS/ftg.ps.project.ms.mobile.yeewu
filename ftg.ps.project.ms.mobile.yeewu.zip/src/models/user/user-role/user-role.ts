export class UserRole {
    key?: string;
    userID: number;
    roleID: number;
}