export class RoleOperation {
    key?: string;
    roleOpsID: number;
    opsRoleID: number;
}