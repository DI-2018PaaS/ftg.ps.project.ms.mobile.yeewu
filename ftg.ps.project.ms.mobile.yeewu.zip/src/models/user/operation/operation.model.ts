export class Operation {
    key?: string;
    operationUniqueID:  number;
    operationName: string;
    operationDescription: string;
}