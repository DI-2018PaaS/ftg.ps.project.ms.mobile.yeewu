export class MotDePasse 
{   
    key?: string;
    valeurMotDePasse: string;
    mdpOwnerUser: number;
    lastMotDePasse: string;
    mdpCreationDate: string;
    mdpLastConnectionDate: string;
    mdpLastModificationDate: string;
}