export class UtilisateurMotDePasse {
    key?: string;
    usersID: number;
    passWordID: number;
}