export class Role {
    key?: string;
    roleUniqueID: number;
    roleName: string;
    acteurTypeID: number;
}