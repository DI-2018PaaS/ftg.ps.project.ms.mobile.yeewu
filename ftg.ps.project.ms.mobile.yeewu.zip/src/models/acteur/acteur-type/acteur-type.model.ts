export class ActeurType {
    key?: string;
    idActeurType: number;
    libelleActeur: string;
}
