export class Animateur
{
    key?: string;
    animateurId: number;
    type: string;
    nom: string;
    prenom: string;
    email: string;
    telephone: string;
    userCreated: number;
    userLastModif: number;
    dateCreated: string;
    dateLastModif: string;
}