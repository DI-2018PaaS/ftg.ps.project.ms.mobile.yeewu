export class Fournisseur 
{
    key?: string;
    fournisseurId: number;
    type: string;
    nom: string;
    prenom: string;
    email: string;
    telephone: string;
    userCreated: number;
    userLastModif: number;
    dateCreated: string;
    dateLastModif: string; 
}