export class Banque {
    key?: string;
    banqueId: number;
    raisonSociale: string;
    email: string;
    siteWeb: string;
    telephone: string;
    capital: number;
    chiffreDaffaire: number;
    userCreated: number;
    userLastModif: number;
    dateCreated: string;
    dateLastModif: string; 
}