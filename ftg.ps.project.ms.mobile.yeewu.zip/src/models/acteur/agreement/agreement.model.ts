export class Agreement
{
    key?: string;
    agreementId: number;
    numeroAgrement: string;
    dateAttibution: string;
    dateDebValidite: string;
    dateFinValidite: string;
    status: true;
    userCreated: number;
    userLastModif: number;
    dateCreated: string;
    dateLastModif: string;
    niveauAgreement: number;
    animateurID: number;
    fournisseurID: number;
}