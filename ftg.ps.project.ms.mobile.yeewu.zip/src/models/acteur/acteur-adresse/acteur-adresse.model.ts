export class ActeurAdresse {
    key?: string;
    addresseId: number;
    acteurId: number;
}