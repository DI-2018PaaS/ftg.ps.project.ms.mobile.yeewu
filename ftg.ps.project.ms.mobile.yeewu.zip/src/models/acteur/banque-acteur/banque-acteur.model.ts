export class BanqueActeur 
{
    key?: string;
    banqueId: number;
    acteurId: number;
}