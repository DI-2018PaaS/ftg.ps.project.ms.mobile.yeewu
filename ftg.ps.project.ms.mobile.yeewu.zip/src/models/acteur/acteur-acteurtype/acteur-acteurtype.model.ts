export class ActeurTypeActeur {
    key?: string;
    idActeurType: number;
    idActeur: number;
}