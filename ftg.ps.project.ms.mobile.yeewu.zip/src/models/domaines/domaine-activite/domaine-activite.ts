export class DomaineActivite{
    key?: string;
    idDomaine: number;
    idActivite: number;
}