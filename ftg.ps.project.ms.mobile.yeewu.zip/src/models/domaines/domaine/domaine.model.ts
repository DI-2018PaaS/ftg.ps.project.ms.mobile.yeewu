export class Domaine 
{
    key?: string;
    domaineId: number;
    nom: string;
    description: string;
    status: true;
    userCreated: number;
    userLastModif: number;
    createdDate: string;
    dateastModif: string;
}