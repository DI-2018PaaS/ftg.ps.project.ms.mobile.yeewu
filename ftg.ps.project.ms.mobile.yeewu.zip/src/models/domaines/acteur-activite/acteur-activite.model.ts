export class ActeurActivite{
    key?: string;
    idActeur: number;
    idActivite: number;
}