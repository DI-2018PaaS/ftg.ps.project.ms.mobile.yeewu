export class Activite {
    key?: string;
    activiteId: number;
    nom: string;
    description: string;
    categorie: string;
    dateDebut: string;
    dateFin: string;
    status: true;
    userCreated: number;
    userLastModif: number;
    createdDate: string;
    dateLastModif: string;
}