export class DirectPaiement {
    key?: string;
    idModePaiement: number;
    libelle: string;
    description: number;
}