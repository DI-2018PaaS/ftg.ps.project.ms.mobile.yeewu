export class ReglementCommande {
    key?: string;
    idReglement: number;
    dateReglement: string;
    idBonDeCommande: number;
}