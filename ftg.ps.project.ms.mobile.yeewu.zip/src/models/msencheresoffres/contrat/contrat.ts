export class Contrat 
{
    key?: string;
    nContrat : number;
    dateSignatureContrat : Date;
    nFournisseurExt : number;
}