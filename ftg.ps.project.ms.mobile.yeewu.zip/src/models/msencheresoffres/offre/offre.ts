export class Offre {
	key?: string;
    nUniqueOffre :  number;
    dateLancement :  Date;
    dateClotureOffre :  Date;
    quantiteProduit : number;
    nAuteurOffre : number;
    typeAuteurOffre : string;
    activityID : number;
    typeArticle : number;
    contratId : number;
}