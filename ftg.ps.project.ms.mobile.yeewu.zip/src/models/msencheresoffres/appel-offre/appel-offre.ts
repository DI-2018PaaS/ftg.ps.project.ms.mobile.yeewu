export class AppelOffre 
{
	key?: string;
    nInscription : number;
    dateReponseOffre : Date;
    nUniqueOffre : number;
    nFournisseurExt : number;
    offreId : number;
}