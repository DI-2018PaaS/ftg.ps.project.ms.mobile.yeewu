export class OffreEnchere 
{
    key?: string;
    nInscription : number;
    nUniqueEnchere : number;
    dateReponseEnchere : Date;
    nActeurExt : number;
    enchereId : number;
}