export class MagasinProduit {
    key?: string;
    magasinId: number;
    produitId: number;
}