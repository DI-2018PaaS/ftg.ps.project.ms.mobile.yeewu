export class BonCommande {
    key?: string;
    numero: number;
    dateEmission: string;
    dateReglement: string;
    acheteurId: number;
    reglementCmdId: number;
}