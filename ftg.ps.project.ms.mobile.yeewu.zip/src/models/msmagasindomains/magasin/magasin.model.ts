export class Magasin {
    key?: string;
   	nIdProprietaire: number;
    ref: string;
    adresse: string;
    description: string;
}