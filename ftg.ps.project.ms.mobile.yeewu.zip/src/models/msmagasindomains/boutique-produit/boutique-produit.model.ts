export class BoutiqueProduit {
    key?: string;
    boutiqueId: number;
    produitId: number;
}