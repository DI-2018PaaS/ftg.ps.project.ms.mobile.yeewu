export class Service {
    key?: string;
    code: string;
    designation: string;
    prixUnitaire: number;
    descriptionProduit: string;
    zoneGeographiqueId: number;
}