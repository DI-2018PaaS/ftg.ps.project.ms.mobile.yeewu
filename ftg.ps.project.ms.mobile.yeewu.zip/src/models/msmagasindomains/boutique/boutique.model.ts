export class Boutique {
    key?: string;
    nIdProprietaire: number;
    ref: string;
    adresse: string;
    description: string;
}