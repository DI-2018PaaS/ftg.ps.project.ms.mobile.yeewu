export class BonLivraison {
    key?: string;
    numero: number;
}