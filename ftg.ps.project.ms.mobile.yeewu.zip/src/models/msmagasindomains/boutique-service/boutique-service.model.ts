export class BoutiqueService {
    key?: string;
    boutiqueId: number;
    serviceId: number;
}