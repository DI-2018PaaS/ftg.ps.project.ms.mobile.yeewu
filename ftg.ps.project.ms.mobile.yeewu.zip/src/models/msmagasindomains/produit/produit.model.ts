export class Produit {
    key?: string;
    code: string;
    designation: string;
    prixUnitaire: number;
    descriptionProduit: string;
    zoneGeographiqueId: number;
}