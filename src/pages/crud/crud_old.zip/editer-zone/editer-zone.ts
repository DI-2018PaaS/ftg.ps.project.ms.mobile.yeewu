import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-zone',
  templateUrl: 'editer-zone.html'
})
export class EditerZonePage {

  constructor(public navCtrl: NavController) {
  }
  
}
