import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-operation',
  templateUrl: 'editer-operation.html'
})
export class EditerOperationPage {

  constructor(public navCtrl: NavController) {
  }
  
}
