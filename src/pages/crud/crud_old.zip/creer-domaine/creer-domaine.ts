import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-domaine',
  templateUrl: 'creer-domaine.html'
})
export class CreerDomainePage {

  constructor(public navCtrl: NavController) {
  }
  
}
