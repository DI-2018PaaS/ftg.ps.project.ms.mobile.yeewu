import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-role',
  templateUrl: 'editer-role.html'
})
export class EditerRolePage {

  constructor(public navCtrl: NavController) {
  }
  
}
