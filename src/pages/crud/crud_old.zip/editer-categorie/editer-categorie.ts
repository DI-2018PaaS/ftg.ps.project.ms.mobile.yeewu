import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-categorie',
  templateUrl: 'editer-categorie.html'
})
export class EditerCategoriePage {

  constructor(public navCtrl: NavController) {
  }
  
}
