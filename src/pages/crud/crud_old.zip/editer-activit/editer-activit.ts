import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-activit',
  templateUrl: 'editer-activit.html'
})
export class EditerActivitPage {

  constructor(public navCtrl: NavController) {
  }
  
}
