import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-type-acteur',
  templateUrl: 'editer-type-acteur.html'
})
export class EditerTypeActeurPage {

  constructor(public navCtrl: NavController) {
  }
  
}
