import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-zone',
  templateUrl: 'creer-zone.html'
})
export class CreerZonePage {

  constructor(public navCtrl: NavController) {
  }
  
}
