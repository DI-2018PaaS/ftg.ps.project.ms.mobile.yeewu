import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-creer-offre',
  templateUrl: 'creer-offre.html'
})
export class CreerOffrePage {

  constructor(public navCtrl: NavController) {
  }
  
}
