import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-editer-domaine',
  templateUrl: 'editer-domaine.html'
})
export class EditerDomainePage {

  constructor(public navCtrl: NavController) {
  }
  
}
